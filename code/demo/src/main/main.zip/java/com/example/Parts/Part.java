package com.example.Parts;

import java.util.ArrayList;
import java.util.Date;

public interface Part {
//    List<Option> options = new ArrayList<Option>();
    Date made = null;

    void print();
    String getName();
}
