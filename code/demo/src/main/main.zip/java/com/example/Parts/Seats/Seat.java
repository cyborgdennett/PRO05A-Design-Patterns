package com.example.Parts.Seats;

import com.example.Parts.Part;

public interface Seat extends Part {

}
