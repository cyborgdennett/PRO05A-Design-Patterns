package com.example.Parts.Armoring;

public class Armor implements Armoring {
    public Armor() {
    }

    public void activate() {
    }

    public void print() {
    }
}