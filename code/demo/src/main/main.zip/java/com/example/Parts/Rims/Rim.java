package com.example.Parts.Rims;

import com.example.Parts.Part;

public interface Rim extends Part{
    
}
