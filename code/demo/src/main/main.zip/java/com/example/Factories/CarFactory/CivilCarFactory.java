package com.example.Factories.CarFactory;

import com.example.Vehicles.SedanCar;

public class CivilCarFactory {

}
