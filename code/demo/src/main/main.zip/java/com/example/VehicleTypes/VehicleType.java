package com.example.VehicleTypes;

public interface VehicleType {
    void drive();
    void stop();
    void fill();
    String getName();

}
