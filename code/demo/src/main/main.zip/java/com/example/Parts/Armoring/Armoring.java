package com.example.Parts.Armoring;
import com.example.Parts.*;

public interface Armoring extends Part {
    int health = 0;

    void activate();
    default String getName(){
        return "default armor";
    }
}