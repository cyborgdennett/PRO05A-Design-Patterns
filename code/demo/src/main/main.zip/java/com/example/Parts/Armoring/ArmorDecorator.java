package com.example.Parts.Armoring;

public abstract class ArmorDecorator implements Armoring {
    public ArmorDecorator() {
    }

    public void activate() {
    }

    public void print() {
    }
}
